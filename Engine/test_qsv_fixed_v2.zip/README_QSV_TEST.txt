========================================
  ShadowPlay QSV Test Script - Instructions
========================================

WHAT YOU NEED:
1. FFmpeg with QSV support (BtbQ build with "qsv" in filename)
   Download: https://github.com/BtbQ/FFmpeg-Builds/releases
   Pick: ffmpeg-master-latest-win64-gpl-shared-qsv.zip
   Extract ffmpeg.exe to same folder as this script

2. Intel GPU with Quick Sync Video support

3. PowerShell (any version - included in Windows)


HOW TO RUN:
-----------
Option A - FFmpeg in same folder as script:
  powershell -ExecutionPolicy Bypass -File ".\test_qsv.ps1"

Option B - Specify FFmpeg path:
  powershell -ExecutionPolicy Bypass -File ".\test_qsv.ps1" -FFmpegPath "C:\full\path\to\ffmpeg.exe"

Option C - Quick test (fewer tests):
  powershell -ExecutionPolicy Bypass -File ".\test_qsv.ps1" -Quick


WHAT IT TESTS (14 groups, ~60+ tests):
--------------------------------------
  Group 1:  h264_qsv capture methods (ddagrab, gfxcapture, gdigrab)
  Group 2:  h264_qsv rate control (cbr, vbr, icq, cqp, la, la_icq)
  Group 3:  h264_qsv presets (veryslow to faster)
  Group 4:  h264_qsv look-ahead depths
  Group 5:  h264_qsv bitrate tiers (10M-100M)
  Group 6:  h264_qsv FPS and scale
  Group 7:  hevc_qsv capture methods
  Group 8:  hevc_qsv rate control
  Group 9:  hevc_qsv presets
  Group 10: hevc_qsv bitrate tiers
  Group 11: hevc_qsv 10-bit and scale
  Group 12: av1_qsv (if GPU supports)
  Group 13: gdigrab software path
  Group 14: Best config stress test (100Mbps)


OUTPUT FILES:
-------------
  QSV_TestResults.csv  - All test results in CSV format
  Logs\                - FFmpeg log files for each test
  QSV_Tests\           - Temporary video files (auto-deleted)


WHAT TO SEND BACK:
------------------
  1. Screenshot of the summary at the end (PASS/FAIL counts)
  2. The file: QSV_TestResults.csv
  3. If any tests FAIL: screenshot of the FAIL lines

TROUBLESHOOTING:
-----------------
  "h264_qsv NOT FOUND" -> You need QSV-enabled FFmpeg build (BtbQ)
  "ffmpeg.exe not found" -> Use -FFmpegPath with full path
  "Access denied" -> Run as Administrator

Estimated time: 15-30 minutes (each test takes ~8 seconds)
