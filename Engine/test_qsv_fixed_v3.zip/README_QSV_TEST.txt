========================================
  ShadowPlay QSV Test Script v3 - Instructions
========================================

WHAT YOU NEED:
1. FFmpeg with QSV support (BtbQ build with "qsv" in filename)
   Download: https://github.com/BtbQ/FFmpeg-Builds/releases
   Pick: ffmpeg-master-latest-win64-gpl-shared-qsv.zip

2. Intel GPU with Quick Sync Video

3. PowerShell (included in Windows)


HOW TO RUN:
  powershell -ExecutionPolicy Bypass -File ".\test_qsv.ps1" -FFmpegPath ".\ffmpeg.exe" -Quick

IMPORTANT:
  - Each test now has an 8-second duration limit (auto-stops)
  - Quick mode: ~10 tests = ~2 minutes
  - Full mode: ~60 tests = ~8 minutes
  - Send back: screenshot + QSV_TestResults.csv
