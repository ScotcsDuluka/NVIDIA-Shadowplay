Imports System.IO
Imports System.Text.Json
Imports System.Text.Json.Serialization

''' <summary>
''' Singleton class สำหรับจัดการ Settings จาก config.json
''' แทนที่ My.Settings ทั้งหมด
''' </summary>
Public Class Settings
    Private Shared _instance As Settings
    Private Shared ReadOnly _lock As New Object()
    
    ' Path สำหรับ config.json
    Private ReadOnly _configPath As String
    
    ' Settings Groups
    Public Property Recording As RecordingSettings
    Public Property Paths As PathSettings
    Public Property UI As UISettings
    Public Property Audio As AudioSettings
    
    ' Singleton Instance
    Public Shared ReadOnly Property Instance As Settings
        Get
            If _instance Is Nothing Then
                SyncLock _lock
                    If _instance Is Nothing Then
                        _instance = New Settings()
                    End If
                End SyncLock
            End If
            Return _instance
        End Get
    End Property
    
    ' Private constructor for Singleton
    Private Sub New()
        ' กำหนด path ของ config.json (อยู่ในโฟลเดอร์เดียวกับ exe)
        _configPath = Path.Combine(Application.StartupPath, "config.json")
        
        ' Initialize default values
        Recording = New RecordingSettings()
        Paths = New PathSettings()
        UI = New UISettings()
        Audio = New AudioSettings()
        
        ' Load from file
        Load()
    End Sub
    
#Region "Settings Classes"
    
    ''' <summary>
    ''' การตั้งค่าการบันทึกวิดีโอ
    ''' </summary>
    Public Class RecordingSettings
        ''' <summary>Encoder ที่ใช้: NVENC_H264, NVENC_H265, QSV_H264, QSV_H265, AMF_H264, AMF_H265, X264, X265</summary>
        Public Property Encoder As String = "NVENC_H264"
        
        ''' <summary>Encoder Preset Index (สำหรับ ComboBox)</summary>
        Public Property EncoderPreset As Integer = 4
        
        ''' <summary>Preset ที่ใช้: UltraFast, SuperFast, VeryFast, Faster, Fast, Medium, Slow, Slower, VerySlow</summary>
        Public Property Preset As String = "Medium"
        
        ''' <summary>Frames Per Second</summary>
        Public Property FPS As Integer = 60
        
        ''' <summary>Bitrate in kbps</summary>
        Public Property Bitrate As Integer = 8000
        
        ''' <summary>Resolution Width</summary>
        Public Property Width As Integer = 1920
        
        ''' <summary>Resolution Height</summary>
        Public Property Height As Integer = 1080
        
        ''' <summary>Replay Buffer Duration (วินาที)</summary>
        Public Property ReplayDuration As Integer = 60
        
        ''' <summary>Current Encoder (แสดงผล)</summary>
        Public Property EncoderNow As String = "NVENC H.264"
        
        ''' <summary>Current Preset (แสดงผล)</summary>
        Public Property PresetNow As String = "Medium"
        
        ' Custom Preset Values (สำหรับ Custom Mode)
        Public Property CustomFPS As Integer = 60
        Public Property CustomBitrate As Integer = 8000
        Public Property CustomWidth As Integer = 1920
        Public Property CustomHeight As Integer = 1080
        Public Property CustomP As Integer = 4
        
        ' Helper Methods
        Public Function GetEncoderType() As String
            Select Case Encoder
                Case "NVENC_H264", "NVENC_H265"
                    Return "NVENC"
                Case "QSV_H264", "QSV_H265"
                    Return "QSV"
                Case "AMF_H264", "AMF_H265"
                    Return "AMF"
                Case Else
                    Return "CPU"
            End Select
        End Function
        
        Public Function GetEncoderCodec() As String
            If Encoder.Contains("H265") OrElse Encoder.Contains("HEVC") Then
                Return "H265"
            Else
                Return "H264"
            End If
        End Function
        
        Public Function GetFFmpegEncoderName() As String
            Select Case Encoder
                Case "NVENC_H264" : Return "h264_nvenc"
                Case "NVENC_H265" : Return "hevc_nvenc"
                Case "QSV_H264" : Return "h264_qsv"
                Case "QSV_H265" : Return "hevc_qsv"
                Case "AMF_H264" : Return "h264_amf"
                Case "AMF_H265" : Return "hevc_amf"
                Case "X264" : Return "libx264"
                Case "X265" : Return "libx265"
                Case Else : Return "h264_nvenc"
            End Select
        End Function
    End Class
    
    ''' <summary>
    ''' การตั้งค่า Path ต่างๆ
    ''' </summary>
    Public Class PathSettings
        ''' <summary>Path สำหรับเก็บ Gallery</summary>
        Public Property GalleryPath As String = ""
        
        ''' <summary>Path สำหรับบันทึกวิดีโอ</summary>
        Public Property SavePath As String = ""
        
        ''' <summary>Path สำหรับ FFmpeg</summary>
        Public Property FFmpegPath As String = "ffmpeg.exe"
        
        Public Sub SetDefaultPaths()
            If String.IsNullOrEmpty(GalleryPath) Then
                GalleryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "NVIDIAShare")
            End If
            If String.IsNullOrEmpty(SavePath) Then
                SavePath = GalleryPath
            End If
        End Sub
    End Class
    
    ''' <summary>
    ''' การตั้งค่า UI
    ''' </summary>
    Public Class UISettings
        ''' <summary>ภาษาที่ใช้: en-US, th-TH</summary>
        Public Property Language As String = "en-US"
        
        ''' <summary>Theme: Light, Dark</summary>
        Public Property Theme As String = "Dark"
        
        ''' <summary>Show notifications</summary>
        Public Property ShowNotifications As Boolean = True
    End Class
    
    ''' <summary>
    ''' การตั้งค่า Audio
    ''' </summary>
    Public Class AudioSettings
        ''' <summary>เปิดใช้งาน Microphone</summary>
        Public Property MicEnabled As Boolean = False
        
        ''' <summary>Microphone Volume (0-100)</summary>
        Public Property MicVolume As Integer = 100
        
        ''' <summary>เปิดใช้งาน System Audio</summary>
        Public Property SystemAudioEnabled As Boolean = True
        
        ''' <summary>System Audio Volume (0-100)</summary>
        Public Property SystemAudioVolume As Integer = 100
    End Class
    
#End Region
    
#Region "Load/Save Methods"
    
    ''' <summary>
    ''' โหลด settings จาก config.json
    ''' </summary>
    Public Sub Load()
        Try
            If File.Exists(_configPath) Then
                Dim json As String = File.ReadAllText(_configPath)
                Dim options As New JsonSerializerOptions With {
                    .PropertyNameCaseInsensitive = True,
                    .WriteIndented = True
                }
                
                Dim loadedSettings = JsonSerializer.Deserialize(Of Settings)(json, options)
                
                If loadedSettings IsNot Nothing Then
                    ' Copy values จาก loaded settings
                    If loadedSettings.Recording IsNot Nothing Then
                        Recording = loadedSettings.Recording
                    End If
                    If loadedSettings.Paths IsNot Nothing Then
                        Paths = loadedSettings.Paths
                    End If
                    If loadedSettings.UI IsNot Nothing Then
                        UI = loadedSettings.UI
                    End If
                    If loadedSettings.Audio IsNot Nothing Then
                        Audio = loadedSettings.Audio
                    End If
                End If
                
                ' ตรวจสอบ default paths
                Paths.SetDefaultPaths()
            Else
                ' สร้าง default config ถ้าไม่มีไฟล์
                Paths.SetDefaultPaths()
                Save()
            End If
        Catch ex As Exception
            ' ถ้า error ให้ใช้ default values
            System.Diagnostics.Debug.WriteLine($"Error loading config: {ex.Message}")
            Recording = New RecordingSettings()
            Paths = New PathSettings()
            Paths.SetDefaultPaths()
            UI = New UISettings()
            Audio = New AudioSettings()
        End Try
    End Sub
    
    ''' <summary>
    ''' บันทึก settings ไป config.json
    ''' </summary>
    Public Sub Save()
        Try
            Dim options As New JsonSerializerOptions With {
                .WriteIndented = True,
                .Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            }
            
            Dim json As String = JsonSerializer.Serialize(Me, options)
            
            ' สร้างโฟลเดอร์ถ้ายังไม่มี
            Dim directory As String = Path.GetDirectoryName(_configPath)
            If Not String.IsNullOrEmpty(directory) AndAlso Not Directory.Exists(directory) Then
                Directory.CreateDirectory(directory)
            End If
            
            File.WriteAllText(_configPath, json)
            System.Diagnostics.Debug.WriteLine($"Config saved to: {_configPath}")
        Catch ex As Exception
            System.Diagnostics.Debug.WriteLine($"Error saving config: {ex.Message}")
            MessageBox.Show($"Error saving configuration: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    
    ''' <summary>
    ''' Reset settings เป็น default
    ''' </summary>
    Public Sub Reset()
        Recording = New RecordingSettings()
        Paths = New PathSettings()
        Paths.SetDefaultPaths()
        UI = New UISettings()
        Audio = New AudioSettings()
        Save()
    End Sub
    
#End Region
    
#Region "Helper Methods สำหรับ ScreenRecorder"
    
    ''' <summary>
    ''' Apply settings ไปยัง ScreenRecorder
    ''' </summary>
    Public Sub ApplyToRecorder(recorder As ScreenRecorder)
        If recorder Is Nothing Then Return
        
        With recorder
            .Encoder = Recording.Encoder
            .EncoderPreset = Recording.EncoderPreset
            .Preset = Recording.Preset
            .Framerate = Recording.FPS
            .Bitrate = Recording.Bitrate
            .ResolutionWidth = Recording.Width
            .ResolutionHeight = Recording.Height
        End With
    End Sub
    
    ''' <summary>
    ''' Load settings จาก ScreenRecorder
    ''' </summary>
    Public Sub LoadFromRecorder(recorder As ScreenRecorder)
        If recorder Is Nothing Then Return
        
        With Recording
            .Encoder = recorder.Encoder
            .EncoderPreset = recorder.EncoderPreset
            .Preset = recorder.Preset
            .FPS = recorder.Framerate
            .Bitrate = recorder.Bitrate
            .Width = recorder.ResolutionWidth
            .Height = recorder.ResolutionHeight
        End With
    End Sub
    
#End Region
    
#Region "Helper Methods สำหรับ UI Controls"
    
    ''' <summary>
    ''' ตั้งค่า FPS จาก ComboBox Index
    ''' </summary>
    Public Sub SetFPSFromIndex(index As Integer)
        Dim fpsValues As Integer() = {30, 60, 120, 144}
        If index >= 0 AndAlso index < fpsValues.Length Then
            Recording.FPS = fpsValues(index)
        End If
    End Sub
    
    ''' <summary>
    ''' ได้ Index ของ FPS สำหรับ ComboBox
    ''' </summary>
    Public Function GetFPSIndex() As Integer
        Dim fpsValues As Integer() = {30, 60, 120, 144}
        For i As Integer = 0 To fpsValues.Length - 1
            If fpsValues(i) = Recording.FPS Then
                Return i
            End If
        Next
        Return 1 ' Default: 60
    End Function
    
    ''' <summary>
    ''' ตั้งค่า Bitrate จาก ComboBox Index
    ''' </summary>
    Public Sub SetBitrateFromIndex(index As Integer)
        Dim bitrateValues As Integer() = {2000, 4000, 6000, 8000, 10000, 15000, 20000, 50000}
        If index >= 0 AndAlso index < bitrateValues.Length Then
            Recording.Bitrate = bitrateValues(index)
        End If
    End Sub
    
    ''' <summary>
    ''' ได้ Index ของ Bitrate สำหรับ ComboBox
    ''' </summary>
    Public Function GetBitrateIndex() As Integer
        Dim bitrateValues As Integer() = {2000, 4000, 6000, 8000, 10000, 15000, 20000, 50000}
        For i As Integer = 0 To bitrateValues.Length - 1
            If bitrateValues(i) = Recording.Bitrate Then
                Return i
            End If
        Next
        Return 3 ' Default: 8000
    End Function
    
    ''' <summary>
    ''' ตั้งค่า Encoder จาก ComboBox Index
    ''' </summary>
    Public Sub SetEncoderFromIndex(index As Integer)
        Dim encoders As String() = {"NVENC_H264", "NVENC_H265", "QSV_H264", "QSV_H265", "AMF_H264", "AMF_H265", "X264", "X265"}
        Dim encoderNames As String() = {"NVENC H.264", "NVENC H.265", "Intel QSV H.264", "Intel QSV H.265", "AMD AMF H.264", "AMD AMF H.265", "x264 (CPU)", "x265 (CPU)"}
        
        If index >= 0 AndAlso index < encoders.Length Then
            Recording.Encoder = encoders(index)
            Recording.EncoderNow = encoderNames(index)
        End If
    End Sub
    
    ''' <summary>
    ''' ได้ Index ของ Encoder สำหรับ ComboBox
    ''' </summary>
    Public Function GetEncoderIndex() As Integer
        Dim encoders As String() = {"NVENC_H264", "NVENC_H265", "QSV_H264", "QSV_H265", "AMF_H264", "AMF_H265", "X264", "X265"}
        
        For i As Integer = 0 To encoders.Length - 1
            If encoders(i) = Recording.Encoder Then
                Return i
            End If
        Next
        Return 0 ' Default: NVENC_H264
    End Function
    
    ''' <summary>
    ''' ตั้งค่า Preset จาก ComboBox Index
    ''' </summary>
    Public Sub SetPresetFromIndex(index As Integer)
        Dim presets As String() = {"UltraFast", "SuperFast", "VeryFast", "Faster", "Fast", "Medium", "Slow", "Slower", "VerySlow"}
        
        If index >= 0 AndAlso index < presets.Length Then
            Recording.Preset = presets(index)
            Recording.PresetNow = presets(index)
            Recording.EncoderPreset = index
        End If
    End Sub
    
    ''' <summary>
    ''' ได้ Index ของ Preset สำหรับ ComboBox
    ''' </summary>
    Public Function GetPresetIndex() As Integer
        Return Recording.EncoderPreset
    End Function
    
    ''' <summary>
    ''' ตั้งค่า Resolution จาก ComboBox Index
    ''' </summary>
    Public Sub SetResolutionFromIndex(index As Integer)
        Dim resolutions As (Width As Integer, Height As Integer)() = {
            (1920, 1080),
            (2560, 1440),
            (3840, 2160),
            (1280, 720),
            (854, 480)
        }
        
        If index >= 0 AndAlso index < resolutions.Length Then
            Recording.Width = resolutions(index).Width
            Recording.Height = resolutions(index).Height
        End If
    End Sub
    
    ''' <summary>
    ''' ได้ Index ของ Resolution สำหรับ ComboBox
    ''' </summary>
    Public Function GetResolutionIndex() As Integer
        Dim resolutions As (Width As Integer, Height As Integer)() = {
            (1920, 1080),
            (2560, 1440),
            (3840, 2160),
            (1280, 720),
            (854, 480)
        }
        
        For i As Integer = 0 To resolutions.Length - 1
            If resolutions(i).Width = Recording.Width AndAlso resolutions(i).Height = Recording.Height Then
                Return i
            End If
        Next
        Return 0 ' Default: 1920x1080
    End Function
    
#End Region
    
#Region "Hardware Detection Helpers"
    
    ''' <summary>
    ''' ตรวจสอบว่ามี NVIDIA GPU หรือไม่
    ''' </summary>
    Public Shared Function HasNvidiaGPU() As Boolean
        Try
            For Each obj As System.Management.ManagementObject In New System.Management.ManagementObjectSearcher("SELECT * FROM Win32_VideoController").Get()
                Dim name As String = obj("Name").ToString().ToUpper()
                If name.Contains("NVIDIA") Then
                    Return True
                End If
            Next
        Catch ex As Exception
            System.Diagnostics.Debug.WriteLine($"Error detecting NVIDIA GPU: {ex.Message}")
        End Try
        Return False
    End Function
    
    ''' <summary>
    ''' ตรวจสอบว่ามี Intel GPU หรือไม่
    ''' </summary>
    Public Shared Function HasIntelGPU() As Boolean
        Try
            For Each obj As System.Management.ManagementObject In New System.Management.ManagementObjectSearcher("SELECT * FROM Win32_VideoController").Get()
                Dim name As String = obj("Name").ToString().ToUpper()
                If name.Contains("INTEL") Then
                    Return True
                End If
            Next
        Catch ex As Exception
            System.Diagnostics.Debug.WriteLine($"Error detecting Intel GPU: {ex.Message}")
        End Try
        Return False
    End Function
    
    ''' <summary>
    ''' ตรวจสอบว่ามี AMD GPU หรือไม่
    ''' </summary>
    Public Shared Function HasAMDGPU() As Boolean
        Try
            For Each obj As System.Management.ManagementObject In New System.Management.ManagementObjectSearcher("SELECT * FROM Win32_VideoController").Get()
                Dim name As String = obj("Name").ToString().ToUpper()
                If name.Contains("AMD") OrElse name.Contains("RADEON") Then
                    Return True
                End If
            Next
        Catch ex As Exception
            System.Diagnostics.Debug.WriteLine($"Error detecting AMD GPU: {ex.Message}")
        End Try
        Return False
    End Function
    
    ''' <summary>
    ''' ได้ Default Encoder ตาม Hardware ที่มี
    ''' </summary>
    Public Shared Function GetDefaultEncoder() As String
        If HasNvidiaGPU() Then
            Return "NVENC_H264"
        ElseIf HasIntelGPU() Then
            Return "QSV_H264"
        ElseIf HasAMDGPU() Then
            Return "AMF_H264"
        Else
            Return "X264"
        End If
    End Function
    
#End Region

End Class
