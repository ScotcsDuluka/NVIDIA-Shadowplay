' ═══════════════════════════════════════════════════════════════════════════════
' Base.vb - Main Form (แก้ไขให้ใช้ AppSettings แทน My.Settings)
' ═══════════════════════════════════════════════════════════════════════════════

Imports System.Diagnostics
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Text
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Security.Principal
Imports System.Text
Imports System.Threading
Imports Captrue_Core
Imports Captrue_Core.CaptureCore
Imports Microsoft.Win32
Imports Windows.Graphics.Capture
Imports Windows.Graphics.DirectX
Imports Windows.Graphics.DirectX.Direct3D11
Imports Windows.Media.Devices
Imports WinRT.Interop
Imports System.Windows.Forms
Imports System.Text.Json

Partial Public Class Base

#Region "============================================================================ NATIVE METHODS & STRUCTURES"

    Public clickThrough As Boolean = False

    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = WinAPI.WM_HOTKEY Then
            If _hotkeyService IsNot Nothing Then
                _hotkeyService.ProcessHotkey(m.WParam.ToInt32())
            End If
            Return
        End If

        Const WM_NCHITTEST As Integer = &H84
        Const HTTRANSPARENT As Integer = -1

        If clickThrough AndAlso m.Msg = WM_NCHITTEST Then
            m.Result = CType(HTTRANSPARENT, IntPtr)
            Exit Sub
        End If

        MyBase.WndProc(m)
    End Sub

    Private Const GWL_EXSTYLE As Integer = -20
    Private Const WS_EX_TOOLWINDOW As Integer = &H80
    Private Const WS_EX_APPWINDOW As Integer = &H40000

    ' Virtual Key Codes - Modifier Keys
    Private Const VK_ALT As Integer = &H12
    Private Const VK_SHIFT As Integer = &H10
    Private Const VK_CONTROL As Integer = &H11

    ' Virtual Key Codes - Function Keys
    Private Const VK_F1 As Integer = &H70
    Private Const VK_F2 As Integer = &H71
    Private Const VK_F3 As Integer = &H72
    Private Const VK_F8 As Integer = &H77
    Private Const VK_F9 As Integer = &H78
    Private Const VK_F10 As Integer = &H79
    Private Const VK_F12 As Integer = &H7B

    ' Virtual Key Codes - Letter Keys
    Private Const VK_Z As Integer = &H5A
    Private Const VK_T As Integer = &H54
    Private Const VK_W As Integer = &H57

    ' Virtual Key Codes - Navigation Keys
    Private Const VK_LEFT As Integer = &H25
    Private Const VK_UP As Integer = &H26
    Private Const VK_RIGHT As Integer = &H27
    Private Const VK_DOWN As Integer = &H28

    ' Virtual Key Codes - Other Keys
    Private Const VK_LBUTTON As Integer = &H1
    Private Const VK_RBUTTON As Integer = &H2
    Private Const VK_MBUTTON As Integer = &H4
    Private Const VK_CANCEL As Integer = &H3
    Private Const VK_BACK As Integer = &H8
    Private Const VK_TAB As Integer = &H9
    Private Const VK_CLEAR As Integer = &HC
    Private Const VK_RETURN As Integer = &HD
    Private Const VK_PAUSE As Integer = &H13
    Private Const VK_CAPITAL As Integer = &H14
    Private Const VK_ESCAPE As Integer = &H1B
    Private Const VK_SPACE As Integer = &H20
    Private Const VK_PAGEUP As Integer = &H21
    Private Const VK_PAGEDOWN As Integer = &H22
    Private Const VK_END As Integer = &H23
    Private Const VK_HOME As Integer = &H24
    Private Const VK_SELECT As Integer = &H29
    Private Const VK_PRINT As Integer = &H2A
    Private Const VK_EXECUTE As Integer = &H2B
    Private Const VK_SNAPSHOT As Integer = &H2C
    Private Const VK_INSERT As Integer = &H2D
    Private Const VK_DELETE As Integer = &H2E
    Private Const VK_HELP As Integer = &H2F

    ' Virtual Key Codes - A-Z
    Private Const VK_A As Integer = &H41
    Private Const VK_B As Integer = &H42
    Private Const VK_C As Integer = &H43
    Private Const VK_D As Integer = &H44
    Private Const VK_E As Integer = &H45
    Private Const VK_F As Integer = &H46
    Private Const VK_G As Integer = &H47
    Private Const VK_H As Integer = &H48
    Private Const VK_I As Integer = &H49
    Private Const VK_J As Integer = &H4A
    Private Const VK_K As Integer = &H4B
    Private Const VK_L As Integer = &H4C
    Private Const VK_M As Integer = &H4D
    Private Const VK_N As Integer = &H4E
    Private Const VK_O As Integer = &H4F
    Private Const VK_P As Integer = &H50
    Private Const VK_Q As Integer = &H51
    Private Const VK_R As Integer = &H52
    Private Const VK_S As Integer = &H53
    Private Const VK_U As Integer = &H55
    Private Const VK_V As Integer = &H56
    Private Const VK_X As Integer = &H58
    Private Const VK_Y As Integer = &H59

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function SetWindowLong(hWnd As IntPtr, nIndex As Integer, dwNewLong As Integer) As Integer
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function GetWindowLong(hWnd As IntPtr, nIndex As Integer) As Integer
    End Function

    <DllImport("user32.dll")>
    Private Shared Function GetAsyncKeyState(vKey As Integer) As Short
    End Function

    <DllImport("kernel32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Public Shared Function CreateProcess(
        lpApplicationName As String,
        lpCommandLine As String,
        lpProcessAttributes As IntPtr,
        lpThreadAttributes As IntPtr,
        bInheritHandles As Boolean,
        dwCreationFlags As UInteger,
        lpEnvironment As IntPtr,
        lpCurrentDirectory As String,
        ByRef lpStartupInfo As StartupInfo,
        ByRef lpProcessInformation As ProcessInformation) As Boolean
    End Function

    <StructLayout(LayoutKind.Sequential)>
    Public Structure StartupInfo
        Public cb As UInteger
        Public lpReserved As String
        Public lpDesktop As String
        Public lpTitle As String
        Public dwX As UInteger
        Public dwY As UInteger
        Public dwXSize As UInteger
        Public dwYSize As UInteger
        Public dwFlags As UInteger
        Public wShowWindow As UShort
        Public cbReserved2 As UShort
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=80)>
        Public lpReserved2 As Byte()
        Public hStdInput As IntPtr
        Public hStdOutput As IntPtr
        Public hStdError As IntPtr
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Public Structure ProcessInformation
        Public hProcess As IntPtr
        Public hThread As IntPtr
        Public dwProcessId As UInteger
        Public dwThreadId As UInteger
    End Structure

#End Region

#Region "============================================================================ CONSTANTS & FIELDS"

    Private Const AppName As String = "NVIDIA Shadowplay™"
    Private ReadOnly greenColor As System.Drawing.Color = ColorTranslator.FromHtml("#76B900")

    Private Const DataDirectoryName As String = "NVIDIA_Shadowplay_Data"

    Private Const ReplayOnFile As String = "Replay/on"
    Private Const ReplayOffFile As String = "Replay/off"
    Private Const MicOnFile As String = "mic/mic_on"
    Private Const MicOffFile As String = "mic/mic_off"
    Private Const PrivacyFile As String = "privacy"

    Private isFunctionActive As Boolean = False
    Private isKeyPressed As Boolean = False

    Private isFunctionActive_F1 As Boolean = False
    Private isKeyPressed_F1 As Boolean = False

    Private isFunctionActive_replay As Boolean = False
    Private isKeyPressed_replay As Boolean = False

    Private isFunctionActive_replay_save As Boolean = False
    Private isKeyPressed_replay_save As Boolean = False

    Private isFunctionActive_record As Boolean = False
    Private isKeyPressed_record As Boolean = False

    Private isFunctionActive_p As Boolean = False
    Private isKeyPressed_p As Boolean = False

    Private isFunctionActive_f2 As Boolean = False
    Private isKeyPressed_f2 As Boolean = False

    Public isFunctionActive_f3 As Boolean = False
    Private isKeyPressed_f3 As Boolean = False

    Private isFunctionActive_f8 As Boolean = False
    Private isKeyPressed_f8 As Boolean = False

    Private isNotiOn As Boolean = False
    Private notifierShown As Boolean = False

    ' HotkeyService
    Private WithEvents _hotkeyService As HotkeyService

#End Region

#Region "============================================================================ FORM LOAD & INITIALIZATION"

    Private Sub LoadCurrentLanguage()
        Dim langFolder As String = Path.Combine(Application.StartupPath, "Languages")
        Dim currentFile As String = Path.Combine(langFolder, "current.txt")

        Dim currentLang As String = "en-US"
        If File.Exists(currentFile) Then currentLang = File.ReadAllText(currentFile).Trim()

        Dim langFile As String = Path.Combine(langFolder, currentLang & ".json")
        If Not File.Exists(langFile) Then langFile = Path.Combine(langFolder, "en-US.json")
        LangHelper.LoadLang(langFile)

        Base_Settings.SW_lang.Text = LangHelper.GetText("meta.languageName")
    End Sub

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' ✅ Initialize AppSettings FIRST (load from config.json)
        AppSettings.Initialize()
        Debug.WriteLine("AppSettings initialized")
        Debug.WriteLine("  Encoder: " & AppSettings.Instance.Recording.Encoder)
        Debug.WriteLine("  FPS: " & AppSettings.Instance.Recording.FPS)
        Debug.WriteLine("  Bitrate: " & AppSettings.Instance.Recording.Bitrate)
        Debug.WriteLine("  Resolution: " & AppSettings.Instance.Recording.Width & "x" & AppSettings.Instance.Recording.Height)

        Dim formTypes = System.Reflection.Assembly.GetExecutingAssembly().GetTypes().
        Where(Function(x) x.IsSubclassOf(GetType(Form)) AndAlso Not x.IsAbstract)

        For Each ft In formTypes
            If ft.Name = Me.GetType().Name Then Continue For
            If ft.Name = NoCloseForm.GetType.Name Then Continue For

            Try
                Dim f As Form = CType(Activator.CreateInstance(ft), Form)
                f.Show()
                f.Hide()
                Debug.WriteLine("Preloaded: " & f.Name)
            Catch ex As Exception
                Debug.WriteLine("Skip: " & ft.Name)
            End Try
        Next

        LoadCurrentLanguage()
        InitializeNotifierAPI()
        HideFromAltTab()

        Base_Background_Top.Show()

        Privacy_control.Start()
        LoadMicrophoneData()
        CheckPrivacyControl()

        ' ✅ Use AppSettings instead of My.Settings
        If AppSettings.Instance.Audio.MicEnabled Then
            mic.Text = ""
        Else
            mic.Text = ""
        End If

        Load_App.Start()

        Base_Background_Top.Hide()

        LoadFilePath()
        CreateDataDirectories()
        LoadMicState()
        _hotkeyService = New HotkeyService()
        _hotkeyService.RegisterAll(Me.Handle)
        File.Create(Path.Combine(Application.StartupPath, "Ready")).Dispose()
    End Sub

    Private Sub MainSub_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SET_Back.Location = New Point(80, 160)
        Base_RecordingsSet.Show()
        Base_RecordingsSet.Hide()
        Base_RecordingsSet.Opacity = 1
    End Sub

    Private Sub InitializeNotifierAPI()
        Try
            Dim exePath As String = Path.Combine(Application.StartupPath, "NVIDIA Notifier.exe")
            If Not File.Exists(exePath) Then
                MessageBox.Show(
                    "NVIDIA Notifier Service Could Not Be Started!" & vbCrLf &
                    "Please check if the file exists and you have sufficient permissions.",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error)
                Application.Exit()
            End If
            Process.Start(exePath)
        Catch ex As Exception
            MessageBox.Show("Failed to run NVIDIA Notifier.exe: " & ex.Message)
        End Try
        Dim width As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim height As Integer = Screen.PrimaryScreen.Bounds.Height

        If width <> 1920 OrElse height <> 1080 Then
            ShowNotifier("ErrorResolution")
        Else
            ShowNotifier("notificationOpenShare")
        End If
    End Sub

#End Region

#Region "============================================================================ LOCALIZATION"

    Private Sub Lang_Tick(sender As Object, e As EventArgs) Handles Lang.Tick
        ' Base_Background_Top
        Base_Background_Top.Logo_text.Text = LangHelper.GetText("l10n.nvidiashadowplay")

        ' Base_Gallery
        With Base_Gallery
            .Gallery_l10n.Text = LangHelper.GetText("l10n.gallery")
            .LoactionSaved_l10n.Text = LangHelper.GetText("l10n.LoactionSaved")
            .Saved_l10n.Text = LangHelper.GetText("l10n.done")
            .Openloaction_l10n.Text = LangHelper.GetText("l10n.openLocation")
            .Shortcut_l10n.Text = LangHelper.GetText("l10n.Shortcut")
            .Load_l10n.Text = LangHelper.GetText("l10n.Load")
            .Label3.Text = LangHelper.GetText("l10n.all")
            .text_sub.Text = LangHelper.GetText("l10n.gallerynotready")
        End With

        ' Base_Game_Filter
        Base_Game_Filter.Home_settings.Text = LangHelper.GetText("l10n.mods")

        ' Base_KeySet
        With Base_KeySet
            .text_settings.Text = LangHelper.GetText("l10n.keyboardShortcuts")
            .Key_Tx.Text = LangHelper.GetText("l10n.keyboardShortcuts")
            .action_fn.Text = LangHelper.GetText("l10n.Saved")
            .Reset.Text = LangHelper.GetText("l10n.resetAll")
        End With

        ' Base_Privacy Control
        With Base_Privacy_Control
            .text_settings.Text = LangHelper.GetText("l10n.privacyControl")
            .Label4.Text = LangHelper.GetText("l10n.settingsPrivacySwitch")
            .Label2.Text = LangHelper.GetText("l10n.settingsPrivacyDescribe")
            .action_fn.Text = LangHelper.GetText("l10n.back")
        End With

        With Base_KeySet
            .text_settings.Text = LangHelper.GetText("l10n.keyboardShortcuts")
            .Key_Tx.Text = LangHelper.GetText("l10n.keyboardShortcuts")
            .action_fn.Text = LangHelper.GetText("l10n.Saved")
        End With

        With Base_Overlay_Hub
            .text_settings.Text = LangHelper.GetText("l10n.hudLayout")
            .action_fn.Text = LangHelper.GetText("l10n.back")
            .Label4.Text = LangHelper.GetText("l10n.overlays")
        End With

        ' Base_RecordingsSet
        With Base_RecordingsSet
            .text_settings.Text = LangHelper.GetText("l10n.recordings")
            .action_fn.Text = LangHelper.GetText("l10n.Saved")
            .Label4.Text = LangHelper.GetText("l10n.videoCapture")
            .Label1.Text = LangHelper.GetText("l10n.quality")
            .Label10.Text = LangHelper.GetText("l10n.low")
            .Label8.Text = LangHelper.GetText("l10n.medium")
            .Label6.Text = LangHelper.GetText("l10n.high")
            .C_TEXT.Text = LangHelper.GetText("l10n.custom")
            .Label12.Text = LangHelper.GetText("l10n.resolution")
            .Label13.Text = LangHelper.GetText("l10n.framerate")
            '----
            Dim savedSeconds As Integer = 60
            Try
                ' ✅ Use AppSettings instead of My.Settings
                Dim settingValue As Integer = AppSettings.Instance.Recording.ReplayDuration
                savedSeconds = Math.Max(15, Math.Min(1200, settingValue))
            Catch
            End Try
            savedSeconds = CInt(Math.Round(savedSeconds / 15.0) * 15)
            .UpdateBufferLabel(savedSeconds)
            .UpdateBitrateLabel()
            '----
            .vdo_resetall.Text = LangHelper.GetText("l10n.resetToDefaults")
            .captrueblock.Text = LangHelper.GetText("l10n.settingsVideoCaptureDisable")
            .warm_re.Text = LangHelper.GetText("l10n.captrueresolutionwarm")
            .custom_main.Text = LangHelper.GetText("l10n.custom")
            .advanced_main.Text = LangHelper.GetText("l10n.advanced")
        End With

        With Base_Settings
            .text_settings.Text = LangHelper.GetText("l10n.settings")
            .Back_btn.Text = LangHelper.GetText("l10n.back")
            .text_sub.Text = LangHelper.GetText("l10n.selectmenu")
            .action_fn.Text = LangHelper.GetText("l10n.done")
            .ch.Text = LangHelper.GetText("l10n.checkForUpdates")
        End With

        ' Base Form Controls
        UpdateLocalizedTexts()
        AppSettings.Instance.Save()  ' ✅ Use AppSettings
        Lang.Stop()
    End Sub

    Public Sub UpdateLocalizedTexts()
        Lang.Start()
        text_settings.Text = (Assembly.GetExecutingAssembly().GetName().Version.ToString())
        Label3.Text = LangHelper.GetText("l10n.settings")
        Home_settings.Text = LangHelper.GetText("l10n.preferencesHome")
        text_py.Text = LangHelper.GetText("l10n.connect")
        Label12.Text = LangHelper.GetText("l10n.hudLayout")
        Label21.Text = LangHelper.GetText("l10n.highlights")
        Label17.Text = LangHelper.GetText("l10n.keyboardShortcuts")
        Label19.Text = LangHelper.GetText("l10n.videoCapture")
        nott.Text = LangHelper.GetText("l10n.notifications")
        Text_Mode1.Text = LangHelper.GetText("l10n.screenshots")
        Text_Mode2.Text = LangHelper.GetText("l10n.photos")
        Text_Mode3.Text = LangHelper.GetText("l10n.mods")
        replay.Text = LangHelper.GetText("l10n.instantReplay")
        record.Text = LangHelper.GetText("l10n.manualRecord")
        live.Text = LangHelper.GetText("l10n.broadcastLive")
        s_replay.Text = LangHelper.GetText("l10n.off")
        s_record.Text = LangHelper.GetText("l10n.notRecording")
        s_live.Text = LangHelper.GetText("l10n.NotReady")
        pf.Text = LangHelper.GetText("l10n.upload")
        gallery.Text = LangHelper.GetText("l10n.gallery")
        Label2.Text = LangHelper.GetText("l10n.settings")
        Label10.Text = LangHelper.GetText("l10n.settings")
        Label13.Text = LangHelper.GetText("l10n.start")
        if_replay.Text = LangHelper.GetText("l10n.instantReplayStart")
        Label7.Text = LangHelper.GetText("l10n.Saved")
        Label4.Text = LangHelper.GetText("l10n.privacyControl")
        vdo_setme.Text = LangHelper.GetText("l10n.videoCaptureText")
    End Sub

#End Region

#Region "============================================================================ FILE & DIRECTORY OPERATIONS"

    Private Sub LoadFilePath()
        Dim GalleryPath As String = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
            "Shadowplay",
            "Gallery"
        )

        ' ✅ Use AppSettings instead of My.Settings
        Base_Gallery.txtFilePath.Text = AppSettings.Instance.Paths.GalleryPath

        If String.IsNullOrEmpty(Base_Gallery.txtFilePath.Text) Then
            Base_Gallery.txtFilePath.Text = GalleryPath
            ' Save default path
            AppSettings.Instance.Paths.GalleryPath = GalleryPath
        End If

        Dim directoryPath As String = Base_Gallery.txtFilePath.Text
        If Not Directory.Exists(directoryPath) Then
            Directory.CreateDirectory(directoryPath)
        End If
    End Sub

    Private Sub CreateDataDirectories()
        Dim basePath As String = Path.Combine(Application.StartupPath, DataDirectoryName)
        Dim subdirectories As String() = {"Replay", "Record", "Live", "mic"}

        For Each subdir As String In subdirectories
            My.Computer.FileSystem.CreateDirectory(Path.Combine(basePath, subdir))
        Next
    End Sub

    Private Sub LoadMicrophoneData()
        Dim micOnPath As String = Path.Combine(Application.StartupPath, DataDirectoryName, MicOnFile)
        mic.Text = If(My.Computer.FileSystem.FileExists(micOnPath), "", "")
    End Sub

    Private Sub CheckPrivacyControl()
        Dim privacyPath As String = Path.Combine(Application.StartupPath, DataDirectoryName, PrivacyFile)
        Base_Privacy_Control.py_2.Text = If(
            My.Computer.FileSystem.FileExists(privacyPath),
            LangHelper.GetText("l10n.instantReplayStop"),
           LangHelper.GetText("l10n.instantReplayStart")
        )
    End Sub

#End Region

#Region "============================================================================ SCREEN CAPTURE"

    Private Sub CaptureScreen()
        If Not My.Computer.FileSystem.FileExists(Path.Combine(Application.StartupPath, DataDirectoryName, PrivacyFile)) Then
            ShowNotifier("notificationScreenshotSavedToGallery")
            Return
        End If

        Dim filePath As String = Base_Gallery.txtFilePath.Text
        If String.IsNullOrWhiteSpace(filePath) Then
            ShowNotifier("validsavepath")
            Return
        End If

        Try
            Using bmpScreenshot As New Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
                Using g As Graphics = Graphics.FromImage(bmpScreenshot)
                    g.CopyFromScreen(0, 0, 0, 0, Screen.PrimaryScreen.Bounds.Size)
                End Using

                Dim fileName As String = Path.Combine(filePath, "Shadowplay Screenshot " & DateTime.Now.ToString("dd_MM_ss") & ".png")
                bmpScreenshot.Save(fileName, System.Drawing.Imaging.ImageFormat.Png)

                ShowNotifier(If(Directory.Exists(filePath), "notificationScreenshotSavedToGallery", "validsavepath"))
            End Using
        Catch ex As Exception
            MessageBox.Show("Failed to capture screen: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "============================================================================ NOTIFIER SYSTEM"

    Public Sub ShowNotifier(message As String)
        Dim folderPath As String = Path.Combine(Application.StartupPath, DataDirectoryName)

        If Not Directory.Exists(folderPath) Then
            Directory.CreateDirectory(folderPath)
        End If

        Dim filePath As String = Path.Combine(folderPath, "l10n." & message)
        Try
            File.Create(filePath).Dispose()
        Catch ex As UnauthorizedAccessException
        End Try
    End Sub

#End Region

#Region "============================================================================ WINDOW MANAGEMENT"

    Private Sub HideFromAltTab()
        Dim style As Integer = GetWindowLong(Me.Handle, GWL_EXSTYLE)
        SetWindowLong(Me.Handle, GWL_EXSTYLE, (style Or WS_EX_TOOLWINDOW) And (Not WS_EX_APPWINDOW))
    End Sub

    Protected Overrides Sub OnResize(e As EventArgs)
        MyBase.OnResize(e)
        AlignPanelToTop()
    End Sub

    Private Sub AlignPanelToTop()
        Dim marginTop As Integer = 160

        ' Base
        settings_1.Location = New Point(80, 160)
        Base_Background_Top.Main_menu_list.Location = New Point((Me.ClientSize.Width - Base_Background_Top.Main_menu_list.Width) / 2, marginTop)
        Main_menu_list.Location = New Point((Me.ClientSize.Width - Main_menu_list.Width) / 2, marginTop)

        ' Gallery
        Base_Gallery.settings_1.Location = New Point((Me.ClientSize.Width - Base_Gallery.settings_1.Width) / 2, marginTop)

        ' Settings
        Base_Privacy_Control.settings_1.Location = New Point(695, marginTop)
        Base_RecordingsSet.setre.Location = New Point(695, marginTop)
        Base_Overlay_Hub.settings_1.Location = New Point(695, marginTop)
        Base_Settings.Main_Menu_SET.Location = New Point(695, marginTop)
        Base_KeySet.keyset.Location = New Point(695, marginTop)
    End Sub

#End Region

    Private Sub Base_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ' ✅ Save all settings to config.json
        AppSettings.Instance.Save()
        _hotkeyService?.UnregisterAll()
    End Sub

End Class
