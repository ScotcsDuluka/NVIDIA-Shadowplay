Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Threading

''' <summary>
''' ═══════════════════════════════════════════════════════════════════════════
''' TCP Engine Hub Client — เชื่อมต่อกับ API Hub (port 5000)
''' รับ broadcast commands จาก Overlay และ execute capture operations
''' ═══════════════════════════════════════════════════════════════════════════
'''
''' Architecture:
'''   Overlay → tcp://127.0.0.1:5000 (API Hub) → broadcast → Engine (this)
'''   Engine เชื่อมกับ Hub เป็น TCP Client เหมือน Overlay/Notifier
'''
''' Protocol:
'''   Overlay ส่ง: [Send] NVIDIA Overlay|engine_record_start
'''   Hub broadcast: ไปยังทุก client รวม Engine
'''   Engine รับ → parse command → execute → ส่ง response กลับ
''' ═══════════════════════════════════════════════════════════════════════════
''' </summary>
Public Class EngineHubClient
    Implements IDisposable

#Region "Events"
    ''' <summary>ยกขึ้นเมื่อได้รับ engine command จาก Hub</summary>
    Public Event OnCommandReceived(sender As Object, e As CommandEventArgs)

    ''' <summary>ยกขึ้นเมื่อสถานะการเชื่อมต่อเปลี่ยน</summary>
    Public Event OnConnectionStatusChanged(sender As Object, connected As Boolean)

    ''' <summary>ยกขึ้นเมื่อมี log message</summary>
    Public Event OnLog(sender As Object, message As String)
#End Region

#Region "Private State"
    Private _client As TcpClient
    Private _writer As StreamWriter
    Private _reader As StreamReader
    Private _isConnected As Boolean = False
    Private _cts As CancellationTokenSource
    Private _writeLock As New Object()
    Private _reconnectLock As New Object()

    Private Const HUB_HOST As String = "127.0.0.1"
    Private Const HUB_PORT As Integer = 5000
    Private Const APP_NAME As String = "NVIDIA Engine"
    Private Const RECONNECT_BASE_MS As Integer = 2000
    Private Const RECONNECT_MAX_MS As Integer = 30000
    Private _reconnectDelay As Integer = RECONNECT_BASE_MS
#End Region

#Region "Public Properties"
    Public ReadOnly Property IsConnected As Boolean
        Get
            Return _isConnected
        End Get
    End Property
#End Region

#Region "Connect / Disconnect"
    ''' <summary>เชื่อมต่อกับ Hub และเริ่ม listen</summary>
    Public Sub Connect()
        Try
            Disconnect()
            _cts = New CancellationTokenSource()

            _client = New TcpClient()
            _client.NoDelay = True
            _client.Connect(HUB_HOST, HUB_PORT)

            Dim stream As NetworkStream = _client.GetStream()
            _writer = New StreamWriter(stream) With {.AutoFlush = True}
            _reader = New StreamReader(stream)

            _isConnected = True
            _reconnectDelay = RECONNECT_BASE_MS

            ' Register ตัวเองกับ Hub
            SendRegister()

            RaiseEvent OnConnectionStatusChanged(Me, True)
            RaiseEvent OnLog(Me, "[Engine] Connected to Hub")

            Task.Run(AddressOf ListenLoop, _cts.Token)
            Task.Run(AddressOf PingLoop, _cts.Token)

        Catch ex As Exception
            _isConnected = False
            RaiseEvent OnLog(Me, $"[Engine] Connect failed: {ex.Message}")
            RaiseEvent OnConnectionStatusChanged(Me, False)
            Task.Run(AddressOf ReconnectLoop)
        End Try
    End Sub

    ''' <summary>ตัดการเชื่อมต่อ</summary>
    Public Sub Disconnect()
        _isConnected = False
        If _cts IsNot Nothing Then
            Try : _cts.Cancel() : Catch : End Try
        End If
        If _client IsNot Nothing Then
            Try : _client.Close() : Catch : End Try
        End If
        _client = Nothing
        _writer = Nothing
        _reader = Nothing
    End Sub
#End Region

#Region "Send Methods"
    ''' <summary>ส่ง command ไปยัง Hub (จะ broadcast ไปหา clients อื่น)</summary>
    Public Sub Send(cmd As String, Optional value As String = "")
        If Not IsConnected Then Return

        Try
            SyncLock _writeLock
                Dim msg As String
                If String.IsNullOrEmpty(value) Then
                    msg = $"[Send] {APP_NAME}|{cmd}"
                Else
                    msg = $"[Send] {APP_NAME}|{cmd}:{value}"
                End If
                _writer.WriteLine(msg)
            End SyncLock
        Catch ex As Exception
            Debug.WriteLine($"EngineHubClient.Send Error: {ex.Message}")
            _isConnected = False
            RaiseEvent OnConnectionStatusChanged(Me, False)
        End Try
    End Sub

    ''' <summary>ส่ง log ไปยัง Hub</summary>
    Public Sub SendLog(message As String)
        If Not IsConnected Then Return

        Try
            SyncLock _writeLock
                _writer.WriteLine($"[Receive] {APP_NAME}|{message}")
            End SyncLock
        Catch ex As Exception
            Debug.WriteLine($"EngineHubClient.SendLog Error: {ex.Message}")
            _isConnected = False
        End Try
    End Sub

    ''' <summary>ส่ง response กลับไปยัง Overlay (ผ่าน Hub broadcast)</summary>
    Public Sub SendResponse(command As String, status As String, Optional data As String = "")
        Dim value As String = $"{command},{status}"
        If Not String.IsNullOrEmpty(data) Then
            value &= $",{data}"
        End If
        Send($"engine_response:{value}")
    End Sub

    Private Sub SendRegister()
        Try
            SyncLock _writeLock
                _writer.WriteLine($"[Send] {APP_NAME}|register:NVIDIA Engine")
            End SyncLock
        Catch
        End Try
    End Sub
#End Region

#Region "Listen Loop"
    Private Sub ListenLoop()
        Try
            While _isConnected AndAlso Not _cts.IsCancellationRequested
                Dim msg = _reader.ReadLine()
                If msg Is Nothing Then Exit While

                ' ข้าม pong
                If msg = "[System]|pong" Then Continue While

                ' Parse message
                ProcessMessage(msg)
            End While
        Catch ex As Exception When TypeOf ex Is IOException OrElse TypeOf ex Is OperationCanceledException
            ' ปกติ — disconnect
        Catch ex As Exception
            Debug.WriteLine($"EngineHubClient.ListenLoop Error: {ex.Message}")
        End Try

        _isConnected = False
        RaiseEvent OnConnectionStatusChanged(Me, False)
        Task.Run(AddressOf ReconnectLoop)
    End Sub

    Private Sub PingLoop()
        Try
            While _isConnected AndAlso Not _cts.IsCancellationRequested
                Thread.Sleep(10000)
                If Not IsConnected Then Exit While

                Try
                    SyncLock _writeLock
                        _writer.WriteLine($"[Send] {APP_NAME}|ping")
                    End SyncLock
                Catch
                    Exit While
                End Try
            End While
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ReconnectLoop()
        RaiseEvent OnLog(Me, "[Engine] Reconnecting to Hub...")

        SyncLock _reconnectLock
            While Not _isConnected
                Try
                    _reconnectDelay = Math.Min(_reconnectDelay * 2, RECONNECT_MAX_MS)
                    Thread.Sleep(_reconnectDelay)

                    _cts = New CancellationTokenSource()
                    _client = New TcpClient()
                    _client.NoDelay = True
                    _client.Connect(HUB_HOST, HUB_PORT)

                    Dim stream As NetworkStream = _client.GetStream()
                    _writer = New StreamWriter(stream) With {.AutoFlush = True}
                    _reader = New StreamReader(stream)

                    _isConnected = True
                    _reconnectDelay = RECONNECT_BASE_MS

                    SendRegister()

                    RaiseEvent OnConnectionStatusChanged(Me, True)
                    RaiseEvent OnLog(Me, "[Engine] Reconnected to Hub")

                    Task.Run(AddressOf ListenLoop, _cts.Token)
                    Task.Run(AddressOf PingLoop, _cts.Token)
                    Return

                Catch ex As Exception
                    Debug.WriteLine($"EngineHubClient.ReconnectLoop Error: {ex.Message}")
                    _isConnected = False
                    Try : _client.Close() : Catch : End Try
                End Try
            End While
        End SyncLock
    End Sub
#End Region

#Region "Message Processing"
    ''' <summary>
    ''' Parse ข้อความจาก Hub และฟิลเตอร์เฉพาะ engine_ commands
    ''' Format: [Send] AppName|command:value หรือ [Receive] AppName|command:value
    ''' </summary>
    Private Sub ProcessMessage(msg As String)
        Try
            If Not msg.Contains("|") Then Return

            Dim parts = msg.Split("|"c)
            If parts.Length < 2 Then Return

            Dim data = parts(1)

            ' ข้าม messages ที่ส่งจากตัวเอง
            If msg.Contains(APP_NAME) Then Return

            Dim colonIndex = data.IndexOf(":"c)
            Dim cmd, value As String
            If colonIndex >= 0 Then
                cmd = data.Substring(0, colonIndex)
                value = data.Substring(colonIndex + 1)
            Else
                cmd = data
                value = ""
            End If

            ' ฟิลเตอร์เฉพาะ engine_ commands
            If Not cmd.StartsWith("engine_") Then Return

            RaiseEvent OnLog(Me, $"[Engine] Received: {cmd}={value}")
            RaiseEvent OnCommandReceived(Me, New CommandEventArgs(cmd, value))

        Catch ex As Exception
            Debug.WriteLine($"EngineHubClient.ProcessMessage Error: {ex.Message}")
        End Try
    End Sub
#End Region

#Region "IDisposable"
    Public Sub Dispose() Implements IDisposable.Dispose
        Disconnect()
    End Sub
#End Region

End Class

''' <summary>Event args สำหรับ command ที่รับมา</summary>
Public Class CommandEventArgs
    Inherits EventArgs

    Public Property Command As String
    Public Property Value As String

    Public Sub New(cmd As String, val As String)
        Command = cmd
        Value = val
    End Sub
End Class
